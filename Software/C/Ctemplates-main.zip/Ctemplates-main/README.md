# Ctemplates for visual Studio Code

ctrl-Shift+B to start the scripts


## Development:
1. C:DEBUG (FOLDER / SINGLE FILE)
2. Execute: DEBUG Program

## Production(Release):
1. C:Release
2. Execute: Release Program

## My Workflow:
1. download template
2. using diagrams -> flowchart for brainstomring the code needs ( https://app.diagrams.net/ )
3. write single function (steps) that are needed generalizes to the main 
4. write the code :-)
5 destructure to the declaration in the header file bib.h and the function code to the bib.c
6. Debug again and again

"stay opensource"
"stay free"
"stay healty"
/w
"Happy coding" 

For questions or needs write me: tjark.ziehm@ohioh.de

TIP: Read the book from the Master of Coding.

Clean Code: A Handbook of Agile Software Craftsmanship (Robert C. Martin)

## Extensions:

http://www.figlet.org/
