//=========================================================================================
/*
    _          __             _            _ 
   / \  _   _ / _| __ _  __ _| |__   ___  / |
  / _ \| | | | |_ / _` |/ _` | '_ \ / _ \ | |
 / ___ \ |_| |  _| (_| | (_| | |_) |  __/ | |
/_/   \_\__,_|_|  \__, |\__,_|_.__/ \___| |_|
                  |___/      
*/
// Name: bib.h
// Comments:  bib header for bib.c
// Author: Tjark Ziehm
// Version: 0.01
// Date: January. 2020
// APT Install: Figlet
// needed Extensions: (Visual Studio Code), Todo Tree, (or TODO Highlight ), GitLens,
//                    Bracket Pair Colorizer, Prettier Formatter
//=========================================================================================
// Structure
//=========================================================================================

/*
// TODO:

// FIXME:
*/

//=========================================================================================



// Return Type: int
// Name: getNumberFromUser
// Parameters: None
// Declaration
